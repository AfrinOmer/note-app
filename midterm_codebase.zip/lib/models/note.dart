//! Define the model class Note here

class Note {}
